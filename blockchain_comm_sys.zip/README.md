Full Advanced Blockchain Communication Project

Folders:
- hardhat: smart contract + deploy scripts
- backend: simple Express server (upload placeholder)
- frontend: React + Vite app (WebCrypto, IPFS, MetaMask)

Follow README steps inside the package to run locally (Hardhat node -> deploy -> frontend).
