require('dotenv').config();
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });
const app = express();
app.use(cors());
app.use(bodyParser.json({ limit: '10mb' }));
app.get('/health', (req,res)=>res.json({ status: 'ok' }));
app.post('/upload', upload.single('file'), (req,res)=>{
  if(!req.file) return res.status(400).json({ error: 'no file uploaded' });
  res.json({ path: req.file.path, originalName: req.file.originalname });
});
const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=>console.log('Backend listening on', PORT));
