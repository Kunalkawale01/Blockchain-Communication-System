async function main() {
  const [deployer] = await ethers.getSigners();
  console.log("Deploying contracts with the account:", deployer.address);
  const MessageRegistry = await ethers.getContractFactory("MessageRegistry");
  const registry = await MessageRegistry.deploy();
  await registry.deployed();
  console.log("MessageRegistry deployed to:", registry.address);
  const fs = require('fs');
  fs.writeFileSync('./deployed-address.json', JSON.stringify({ address: registry.address }, null, 2));
}
main().catch((err)=>{ console.error(err); process.exit(1); });
